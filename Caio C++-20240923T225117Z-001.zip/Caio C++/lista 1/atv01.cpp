#include <iostream>
using namespace std;

int main (){
int x;
cout << "Digite um valor: ";
cin >> x;
cout << "O valor digitado foi: " << x;
}
